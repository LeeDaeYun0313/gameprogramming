# dicegame_web
# javascript, html, css, jQuery
# no hosting(only local)
2명이 player가 주사위를 2번씩 던지고
가운데에 들어갈 사직연산 부호가 랜덤으로 정해집니다.
이후 추가로 한번 더 주사위와 부호를 던질지 결정합니다.
최종 던져진 주사위와 부호로 계산된 값이 큰 사람이 승리합니다.
